# -*- coding: utf-8 -*-
"""
Created on Tue Nov  9 23:44:24 2021

@author: Mr Mathonsi MM
"""

##IMPORTING THE LIBRARIES THAT ARE TO BE USED 

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib as plt


pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from datetime import datetime
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics
#Reading the dataset
ford = pd.read_csv(r'C:\Users\Mr Mathonsi MM\Documents\Honours\Project\Data\FORD.csv')


#Define the features and the target


Features = ford.drop('Adj Close', axis = 1)
Features = ford.drop('Date', axis = 1)
Features = Features.values

Target = ford['Adj Close']


#Splitting the dataset into Train and test dataset
X_train, X_test, y_train, y_test = train_test_split(Features, Target,test_size = 0.20)


#X_train = X_train.drop('Date', axis=1)
# X_test = X_test.drop('Date', axis=1)

print('Training Features Shape:', X_train.shape)
print('Training Labels Shape:', y_train.shape)
print('Testing Features Shape:', X_test.shape)
print('Testing Labels Shape:', y_test.shape)



#Build the random forest regression model with random forest regressor function
regressor = RandomForestRegressor(n_estimators = 20, random_state = 0)
regressor.fit(X_train, y_train)

y_pred = regressor.predict(X_test)




print('Mean Absolute Error:', metrics.mean_absolute_error(y_test, y_pred))
print('Mean Squared Error:', metrics.mean_squared_error(y_test, y_pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))


from sklearn.metrics import accuracy_score

print('Accuracy score: ', accuracy_score(y_test, y_pred))



