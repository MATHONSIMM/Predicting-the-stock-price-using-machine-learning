print("HELLO WORLD")

print("I LOVE YOU")

first_name= input("Enter your first name? ")
second_name= input(' Enter your second Name ')

print("Welcome " + first_name  + second_name)


birth_year = input("What is your birth year? ")
age = 2020 - int(birth_year)
print("Your age is ", age)

#first_name = "Mbongiseni"
#second_name = "Mphikeleli"
message = first_name + "[" + second_name + "]  is a Mathematician"
print(message)
print(len(first_name))

## Checking a data type##

 #type()

##input functions##

#input()

print(' your email address is', (first_name.lower()) +'.'+second_name.lower()+'@gmail.com')

####EXERCISE######

number_of_kilometers = input('Enter the number of kilometers')
miles= float(number_of_kilometers) /1.609344
print('Miles =', round(miles,2))



the_1st_number = input('Enter the 1st Number')
the_2nd_number =  input('Enter the 2nd Number')
if the_1st_number < the_2nd_number  :
    print('The 1st number is les than the 2nd number')
elif the_1st_number == the_2nd_number :
    print('The 1st number  is equal to the 2nd number')
else :
    print('The 1st number is greater than the 2nd number')

#first_name = input('Enter your first name ')
#second_name = input('Enter your second name ')
last_name = input(' Enter your surname ')

last = last_name[0]
second = second_name[0]

print("Your initials are ", last + "." + second + last_name )

product_code =  str('037-00901-00027')

print('Country Code;', product_code[:3])
print('Product Code;', product_code[4:9])
print('Branch Code;', product_code[10:]) 

students = ' Senzo , Ntokozo , Mbongiseni '
print(students)
print(type(students))
print(len(students))

list_students = [ ' Senzo' , 'Ntokozo' , 'Mbongiseni ' ]
print(list_students[0])
print(list_students[ :2 ])
print(type(list_students))

months1 = ('Jan', 'Feb' , 'Mar' , 'Apr' , 'May' , 'Jun' )
print(type(months1))
print(months1[0])

months2 = ('Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')

months = months1 + months2
print(months)

list_students[0] = ("January")
print(list_students)
 
list_students.pop()
print(list_students)

list_students.append('Mphikeleli')
print(list_students)

list_students.insert(0 , 'Chimamanda')
print(list_students)

list_students.pop(1)
print(list_students)

list_students[0] = 'Senzo'
list_students.remove('Ntokozo')
print(list_students)

print('Area Calculator and Circumference')
import math
radius = int(input("Enter the value of the Radius(r) "))
area = math.pi * (radius^2)
circumference = 2*math.pi*radius
print('Your Area is ' , round(area, 2))
print('Your Circumference is ' , round(circumference,2))

months = ("January", "February","March","April","May","June","July","August","September","October","November","December")

birthday = input("What is your birthday in this format DD-MM-YYYY ")
index = int(birthday[3:5] ) - 1
bd_month = months[index]

print("You were born in", bd_month)

##EXERCISE DICTIONARY##

print('Your Dictionary')

name = input('Enter your 1st name ')
surname = input('Enter your Surname ')
age = input('Enter your year of birth ')
current_age = 2020 - int(age)
adress = input('Enter you home adress ')
phone_number = input('Enter your phone your phone Number ')

personal_dictionary = { "name": name , "surname": surname , "age": current_age , "adress": adress , "phone_number": phone_number }
print(personal_dictionary)

key = input("What information you want to search about? ")

print(personal_dictionary.get(key,"The information you are looking for is not available"))


 


            
   
