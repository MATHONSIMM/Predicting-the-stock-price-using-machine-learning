# -*- coding: utf-8 -*-
"""
Created on Wed Dec 29 11:36:37 2021

@author: Mr Mathonsi MM
"""
#importing libraries and visualisation tools

# Data Manipulation
import numpy as np
import pandas as pd
import seaborn as sns
import os

#Statistic descriptives
from scipy.stats import skew
from scipy.stats import kurtosis

#splitting the dataset
from sklearn.model_selection import train_test_split

#Changinging the data type of date
from datetime import datetime

#Data scalling 
from sklearn.preprocessing import MinMaxScaler

# Plotting graphs
import matplotlib.pyplot as plt
from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()

# Machine learning libraries
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier

#Evaluation techniques 
from sklearn.metrics import accuracy_score
from sklearn import metrics

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
#reading the dataset of listed companies

#Apple dataset
apple = pd.read_csv(r"C:\Users\Mr Mathonsi MM\Documents\Honours/Project\Data\AAPL.csv")

apple.head()

# Predictor variables For the APPLE DATASET
apple['Open-Close']= apple.Open -apple.Close
apple['High-Low']  = apple.High - apple.Low
apple = apple.dropna()
X = apple[['Open-Close', 'High-Low']]


# Target variable For the APPLE DATASET
Y = np.where(apple['Adj Close'].shift(-1)>apple['Adj Close'],1,-1)

#Viewing the first five rows of the Predictor variables
X.head()

Y = (Y - min(Y))/(max(Y)- min(Y))


# Splitting the dataset Into training and tests dataset for Apple
split_percentage = 0.2
split = int(split_percentage*len(apple))

X_train = X[:split]
Y_train = Y[:split]

X_test = X[split:]
Y_test = Y[split:]

# Instantiate KNN learning model(k=5)
knn = KNeighborsClassifier(n_neighbors=160)

# fit the model
knn.fit(X_train, Y_train)

# Accuracy Score
accuracy_train = accuracy_score(Y_train, knn.predict(X_train))*100.0
accuracy_test = accuracy_score(Y_test, knn.predict(X_test))*100.0

print ('Train_data Accuracy for Apple dataset: %.2f' %accuracy_train)
print ('Test_data Accuracy for Apple dataset: %.2f' %accuracy_test)

%matplotlib inline
plt.style.use('classic')
#plt.figure(figsize=(10,5))

# Predicted Signal
apple['Predicted_Signal'] = knn.predict(X)

# SPY Cumulative Returns
apple['SPY_returns'] = np.log(apple['Adj Close']/apple['Adj Close'].shift(1))
Cumulative_SPY_returns = apple[split:]['SPY_returns'].cumsum()*100

# Cumulative Strategy Returns 
apple['Startegy_returns'] = apple['SPY_returns']* apple['Predicted_Signal'].shift(1)
Cumulative_Strategy_returns = apple[split:]['Startegy_returns'].cumsum()*100

# Plot the results to visualize the performance
#Plot for Apple dataset
#lt.subplot(2,2,1)
plt.figure(figsize=(16,5))
plt.plot(Cumulative_SPY_returns, color='r',label = 'SPY Cummulative Returns')
plt.plot(Cumulative_Strategy_returns, color='b', label = 'Strategy Returns')
plt.xlabel('')
plt.ylabel('Cummulative return')
plt.legend()
plt.title('Apple')
plt.savefig('knnapple.jpg')
plt.show()

from sklearn.metrics import mean_absolute_error

mape = mean_absolute_error(Y_train, X_train)*100
print(mape)