# -*- coding: utf-8 -*-
"""
Created on Fri Oct 22 00:26:10 2021

@author: Mr Mathonsi MM
"""

# importing libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)

#importing the machine learning algorithms
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

from sklearn.metrics import accuracy_score
from datetime import datetime

#reading the dataset of listed companies

#Apple dataset
apple = pd.read_csv(r"C:\Users\Mr Mathonsi MM\Documents\Honours/Project\Data\AAPL.csv")

apple.head()

#Creating variable for the missing values
missing_value = ['N\A', 'na', np.nan]
apple = pd.read_csv(r"C:\Users\Mr Mathonsi MM\Documents\Honours/Project\Data\AAPL.csv", na_values = missing_value)
apple.isnull().sum()

checking_missing_values = apple.isnull().sum()
checking_missing_values
#Drawing the heatmap to check the missing values
sns.heatmap(apple.isnull(), yticklabels = False)

#Changing the datatype of the listed comenies, "Date" from strings to Date, so that we can be able use use the date when plotting

apple['Date'] = pd.to_datetime(apple.Date)

#Ploting the Apple dataset
plt.style.use('classic')

plt.figure(figsize = (6,3))
sns.set(style = 'darkgrid')
plt.plot(apple['Date'], apple['Adj Close'], 'r' , label = 'Apple close price') 
plt.xlabel('Period')
plt.ylabel('Closing price (cents)')
plt.legend()
plt.grid(False)

plt.style.use('classic')

plt.figure(figsize = (6,3))
sns.set(style = 'darkgrid')
plt.plot(apple['Date'], apple['Volume'], 'r' , label = 'Apple close price') 
plt.xlabel('Period')
plt.ylabel('Volume')
plt.legend()
plt.grid(False)
plt.savefig('Volume.jpg')

#Descriptive statistics for Apple

describe = apple['Adj Close'].describe()
describe

#plotting a bargraph to check the skweness of the dataset
#%matplotlib inline
plt.style.use('classic')

plt.figure(figsize = (12,6))
sns.set(style = 'darkgrid')

sns.displot(apple['Adj Close'])

plt.xlabel('Period')
plt.ylabel('Closing price (cents)')
plt.legend("Ford")
plt.grid(False)


#plotting the box plot to check outliers 

#%matplotlib inline
plt.style.use('classic')

plt.figure(figsize = (6,3))
sns.set(style = 'darkgrid')
plt.boxplot(apple['Adj Close'])
plt.xlabel('Period')
plt.ylabel('Closing price (cents)')
plt.legend("Apple")
plt.grid(False)

#Now we normalise the data
def normalise_data(apple):
    # apple on input should contain only one column with the price data (plus dataframe index)
    min = apple.min()
    max = apple.max()
    x = apple
    
    # time series normalization part
    # y will be a column in a dataframe
    y = (x - min) / (max - min)
    
    return y
apple['Normalised Adj Close'] = normalise_data(apple['Adj Close'])
print(apple)

#Now plot the normilised adj close price

#Ploting the Apple dataset
plt.style.use('classic')

plt.figure(figsize = (6,3))
sns.set(style = 'darkgrid')
plt.plot(apple['Date'], apple['Normalised Adj Close'], 'b' , label = 'Apple close price') 
plt.xlabel('Period')
plt.ylabel('Closing price (cents)')
plt.legend()
plt.grid(False)

#Now plot the box plot of the  normilised adj close price

#%matplotlib inline
plt.style.use('classic')

plt.figure(figsize = (6,3))
sns.set(style = 'darkgrid')
plt.boxplot(apple['Normalised Adj Close'])
plt.xlabel('Period')
plt.ylabel('Closing price (cents)')
plt.legend("Apple")
plt.grid(False)


##Splitting the dataset in two parts particulary the training and test set
Features = apple.drop('Adj Close', axis = 1)
Target = apple['Adj Close']
Features_list = list(apple.columns)
Features = Data.values
X_train, X_test, y_train, y_test = train_test_split(Features, Target,test_size = 0.20)
                                                  
print('Training Features Shape:', X_train.shape)
print('Training Labels Shape:', y_train.shape)
print('Testing Features Shape:', X_test.shape)
print('Testing Labels Shape:', y_test.shape)

#regressor = RandomForestRegressor(n_estimators = 10, random_state = 0)
#regressor.fit(X_train.np.reshape(-1,1), y_train.np.reshape(-1,1))

X_train.head()
print(X_train)

x_train = X_train.drop('Date',axis=1)
x_test = X_test.drop('Date',axis=1)

##Now applying the random forest
params = {'n_estimators': 10, 'min_samples_split': 10,'min_samples_leaf': 3,
          'max_features': 'auto', 'max_depth': 20, 'bootstrap': True}

# Instantiate the model
Opti_rf = RandomForestRegressor(**params)
Opti_rf.fit(x_train,y_train)

#5 Predicting a new result
red = Opti_rf.predict(x_test)

##Plotting the graph
plt.figure(figsize=(12,6))
plt.plot(X_test['Date'], pred ,'ro-',label='Predicted')
plt.plot(X_test['Date'], y_test,'bo-',label='Observed')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.grid(True)

#from sklearn.model_selection import train_test_split

#X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
